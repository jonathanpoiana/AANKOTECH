import 'package:firebase_auth/firebase_auth.dart';
import 'package:rxdart/rxdart.dart';

class Aanko2ndDraftFirebaseUser {
  Aanko2ndDraftFirebaseUser(this.user);
  User user;
  bool get loggedIn => user != null;
}

Aanko2ndDraftFirebaseUser currentUser;
bool get loggedIn => currentUser?.loggedIn ?? false;
Stream<Aanko2ndDraftFirebaseUser> aanko2ndDraftFirebaseUserStream() =>
    FirebaseAuth.instance
        .authStateChanges()
        .debounce((user) => user == null && !loggedIn
            ? TimerStream(true, const Duration(seconds: 1))
            : Stream.value(user))
        .map<Aanko2ndDraftFirebaseUser>(
            (user) => currentUser = Aanko2ndDraftFirebaseUser(user));
