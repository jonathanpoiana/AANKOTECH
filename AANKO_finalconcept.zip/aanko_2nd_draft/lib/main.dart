import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'auth/firebase_user_provider.dart';
import 'auth/auth_util.dart';

import 'flutter_flow/flutter_flow_theme.dart';
import 'flutter_flow/internationalization.dart';
import 'package:aanko_2nd_draft/login_page/login_page_widget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'flutter_flow/flutter_flow_theme.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'home_page/home_page_widget.dart';
import 'my_events/my_events_widget.dart';
import 'find_teams/find_teams_widget.dart';
import 'profile_page/profile_page_widget.dart';
import 'primaryrolebadgespage/primaryrolebadgespage_widget.dart';
import 'gpslocation/gpslocation_widget.dart';
import 'createpost/createpost_widget.dart';
import 'all_chats/all_chats_widget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  // This widget is the root of your application.
  @override
  _MyAppState createState() => _MyAppState();

  static _MyAppState of(BuildContext context) =>
      context.findAncestorStateOfType<_MyAppState>();
}

class _MyAppState extends State<MyApp> {
  Locale _locale;
  ThemeMode _themeMode = ThemeMode.system;
  Stream<Aanko2ndDraftFirebaseUser> userStream;
  Aanko2ndDraftFirebaseUser initialUser;
  bool displaySplashImage = true;
  final authUserSub = authenticatedUserStream.listen((_) {});

  void setLocale(Locale value) => setState(() => _locale = value);
  void setThemeMode(ThemeMode mode) => setState(() {
        _themeMode = mode;
      });

  @override
  void initState() {
    super.initState();
    userStream = aanko2ndDraftFirebaseUserStream()
      ..listen((user) => initialUser ?? setState(() => initialUser = user));
    Future.delayed(
        Duration(seconds: 1), () => setState(() => displaySplashImage = false));
  }

  @override
  void dispose() {
    authUserSub.cancel();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aanko 2nd draft',
      localizationsDelegates: [
        FFLocalizationsDelegate(),
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      locale: _locale,
      supportedLocales: const [Locale('en', '')],
      theme: ThemeData(brightness: Brightness.light),
      themeMode: _themeMode,
      home: initialUser == null || displaySplashImage
          ? Container(
              color: Colors.transparent,
              child: Builder(
                builder: (context) => Image.asset(
                  'assets/images/joel-filipe-225643-unsplash.jpg',
                  fit: BoxFit.fill,
                ),
              ),
            )
          : currentUser.loggedIn
              ? NavBarPage()
              : LoginPageWidget(),
    );
  }
}

class NavBarPage extends StatefulWidget {
  NavBarPage({Key key, this.initialPage}) : super(key: key);

  final String initialPage;

  @override
  _NavBarPageState createState() => _NavBarPageState();
}

/// This is the private State class that goes with NavBarPage.
class _NavBarPageState extends State<NavBarPage> {
  String _currentPage = 'homePage';

  @override
  void initState() {
    super.initState();
    _currentPage = widget.initialPage ?? _currentPage;
  }

  @override
  Widget build(BuildContext context) {
    final tabs = {
      'homePage': HomePageWidget(),
      'myEvents': MyEventsWidget(),
      'findTeams': FindTeamsWidget(),
      'profilePage': ProfilePageWidget(),
      'primaryrolebadgespage': PrimaryrolebadgespageWidget(),
      'gpslocation': GpslocationWidget(),
      'createpost': CreatepostWidget(),
      'AllChats': AllChatsWidget(),
    };
    final currentIndex = tabs.keys.toList().indexOf(_currentPage);
    return Scaffold(
      body: tabs[_currentPage],
      bottomNavigationBar: GNav(
        selectedIndex: currentIndex,
        onTabChange: (i) =>
            setState(() => _currentPage = tabs.keys.toList()[i]),
        backgroundColor: FlutterFlowTheme.of(context).darkBackground,
        color: FlutterFlowTheme.of(context).grayLight,
        activeColor: Colors.white,
        tabBackgroundColor: Color(0x00000000),
        tabBorderRadius: 100,
        tabMargin: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 0),
        padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 0),
        gap: 0,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        duration: Duration(milliseconds: 500),
        haptic: false,
        tabs: [
          GButton(
            icon: currentIndex == 0 ? Icons.home_rounded : Icons.home_outlined,
            text: ' Home',
            iconSize: 24,
          ),
          GButton(
            icon: currentIndex == 1
                ? Icons.date_range_rounded
                : Icons.date_range_outlined,
            text: 'Appointments',
            iconSize: 24,
          ),
          GButton(
            icon: currentIndex == 2 ? Icons.group_add : FontAwesomeIcons.stamp,
            text: 'Teams',
            iconSize: 24,
          ),
          GButton(
            icon: currentIndex == 3
                ? Icons.account_circle_rounded
                : Icons.account_circle_outlined,
            text: 'Profile',
            iconSize: 24,
          ),
          GButton(
            icon: FontAwesomeIcons.solidIdBadge,
            text: 'Roles',
            iconSize: 24,
          ),
          GButton(
            icon: Icons.location_on,
            text: 'Home',
            iconSize: 24,
          ),
          GButton(
            icon: Icons.post_add,
            text: 'Home',
            iconSize: 24,
          ),
          GButton(
            icon: currentIndex == 7
                ? Icons.chat_bubble_rounded
                : Icons.chat_bubble_outline,
            text: 'Chats',
            iconSize: 24,
          )
        ],
      ),
    );
  }
}
